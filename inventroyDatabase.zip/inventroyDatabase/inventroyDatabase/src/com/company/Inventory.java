package com.company;

public class Inventory {

}